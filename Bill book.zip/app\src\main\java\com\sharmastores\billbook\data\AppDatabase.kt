package com.sharmastores.billbook.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [ShopProfile::class, Product::class, Bill::class, BillItem::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun shopProfileDao(): ShopProfileDao
    abstract fun productDao(): ProductDao
    abstract fun billDao(): BillDao
}
