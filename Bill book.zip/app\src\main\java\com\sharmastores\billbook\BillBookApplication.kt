package com.sharmastores.billbook

import android.app.Application
import androidx.room.Room
import com.sharmastores.billbook.data.AppDatabase
import com.sharmastores.billbook.data.BillRepository

class BillBookApplication : Application() {
    lateinit var repository: BillRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "bill-book.db"
        ).build()
        repository = BillRepository(database)
    }
}
