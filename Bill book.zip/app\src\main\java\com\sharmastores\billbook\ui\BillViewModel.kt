package com.sharmastores.billbook.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.sharmastores.billbook.data.BillDraft
import com.sharmastores.billbook.data.BillRepository
import com.sharmastores.billbook.data.Product
import com.sharmastores.billbook.data.ShopProfile
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.CancellationException

class BillViewModel(private val repository: BillRepository) : ViewModel() {
    val products = repository.products.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
    )
    val bills = repository.bills.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
    )
    val profile: StateFlow<ShopProfile> = repository.profile
        .map { it ?: ShopProfile() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ShopProfile())
    val message = MutableStateFlow<String?>(null)

    init {
        viewModelScope.launch { repository.ensureProfile() }
    }

    fun saveProfile(profile: ShopProfile) = runAction { repository.saveProfile(profile) }
    fun saveProduct(product: Product) = runAction { repository.saveProduct(product) }
    fun deleteProduct(id: Long) = runAction { repository.deleteProduct(id) }

    fun saveBill(draft: BillDraft, onSaved: (com.sharmastores.billbook.data.BillWithItems) -> Unit) {
        viewModelScope.launch {
            try {
                onSaved(repository.saveBill(draft, profile.value))
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                message.value = error.message ?: "Could not save bill."
            }
        }
    }

    fun clearMessage() {
        message.value = null
    }

    private fun runAction(action: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                action()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                message.value = error.message ?: "The action could not be completed."
            }
        }
    }

    class Factory(private val repository: BillRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (!modelClass.isAssignableFrom(BillViewModel::class.java)) {
                throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
            return BillViewModel(repository) as T
        }
    }
}
