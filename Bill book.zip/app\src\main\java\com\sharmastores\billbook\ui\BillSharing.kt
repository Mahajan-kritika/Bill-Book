package com.sharmastores.billbook.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.sharmastores.billbook.data.BillWithItems
import com.sharmastores.billbook.data.asRupees
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.text.DateFormat
import java.util.Date
import java.util.Locale

internal fun upiUri(bill: BillWithItems): String? {
    val upiId = bill.bill.upiId.trim()
    if (!Regex("^[A-Za-z0-9._-]+@[A-Za-z0-9.-]+$").matches(upiId)) return null
    fun encoded(value: String) = URLEncoder.encode(value, StandardCharsets.UTF_8.name())
    return "upi://pay?pa=${encoded(upiId)}&pn=${encoded(bill.bill.shopName)}" +
        "&am=${bill.bill.grandTotalPaise.asRupees()}&cu=INR"
}

internal fun createQrBitmap(content: String, size: Int = 440): Bitmap {
    val matrix = QRCodeWriter().encode(
        content,
        BarcodeFormat.QR_CODE,
        size,
        size,
        mapOf(EncodeHintType.MARGIN to 1)
    )
    return Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).apply {
        for (x in 0 until size) for (y in 0 until size) {
            setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
        }
    }
}

internal fun shareBillImage(context: Context, bill: BillWithItems) {
    val width = 900
    val padding = 54f
    val rowHeight = 48f
    val qr = upiUri(bill)?.let { createQrBitmap(it, 340) }
    val headerHeight = 390f
    val summaryHeight = 280f
    val height = (headerHeight + bill.items.size * rowHeight + summaryHeight + if (qr != null) 550 else 100)
        .toInt()
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(Color.WHITE)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(32, 54, 45)
        textSize = 34f
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    fun drawText(text: String, x: Float, y: Float, size: Float = 30f, bold: Boolean = false) {
        paint.textSize = size
        paint.typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        canvas.drawText(text, x, y, paint)
    }
    drawText(bill.bill.shopName, padding, 76f, 44f, true)
    if (bill.bill.ownerName.isNotBlank()) drawText("Owner: ${bill.bill.ownerName}", padding, 116f, 24f)
    drawText(bill.bill.shopAddress, padding, 152f, 24f)
    drawText(bill.bill.shopMobile, padding, 188f, 24f)
    if (bill.bill.gstin.isNotBlank()) drawText("GSTIN: ${bill.bill.gstin}", padding, 224f, 22f)
    paint.color = Color.rgb(225, 238, 230)
    canvas.drawRoundRect(padding, 250f, width - padding, 338f, 18f, 18f, paint)
    paint.color = Color.rgb(32, 54, 45)
    drawText("Bill #${bill.bill.billNumber}", padding + 22f, 288f, 28f, true)
    drawText(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale.getDefault())
        .format(Date(bill.bill.createdAt)), padding + 22f, 323f, 22f)
    var y = 420f
    drawText("Item", padding, y, 24f, true)
    drawText("Qty", 490f, y, 24f, true)
    drawText("Price", 610f, y, 24f, true)
    drawText("Amount", 742f, y, 24f, true)
    y += 42f
    bill.items.forEach { item ->
        drawText(item.productName.take(24), padding, y, 24f)
        drawText(item.quantity, 490f, y, 24f)
        drawText("Rs ${item.unitPricePaise.asRupees()}", 610f, y, 23f)
        drawText("Rs ${item.lineTotalPaise.asRupees()}", 742f, y, 23f)
        y += rowHeight
    }
    y += 18f
    drawText("Subtotal", 520f, y, 26f)
    drawText("Rs ${bill.bill.subtotalPaise.asRupees()}", 742f, y, 26f)
    y += 42f
    drawText("Discount", 520f, y, 26f)
    drawText("- Rs ${bill.bill.discountPaise.asRupees()}", 742f, y, 26f)
    y += 42f
    drawText("Tax", 520f, y, 26f)
    drawText("Rs ${bill.bill.taxPaise.asRupees()}", 742f, y, 26f)
    y += 56f
    paint.color = Color.rgb(225, 238, 230)
    canvas.drawRoundRect(padding, y - 34f, width - padding, y + 24f, 14f, 14f, paint)
    paint.color = Color.rgb(32, 54, 45)
    drawText("TOTAL", padding + 18f, y + 5f, 30f, true)
    drawText("Rs ${bill.bill.grandTotalPaise.asRupees()}", 620f, y + 5f, 30f, true)
    y += 86f
    if (qr != null) {
        drawText("Scan to pay Rs ${bill.bill.grandTotalPaise.asRupees()}", padding, y + 24f, 25f, true)
        canvas.drawBitmap(qr, padding, y + 42f, null)
        drawText("UPI ID: ${bill.bill.upiId}", padding, y + 410f, 22f)
        y += 458f
    } else {
        drawText("UPI QR unavailable: configure a valid UPI ID in Settings.", padding, y, 21f)
        y += 42f
    }
    drawText("Thank you for shopping with us!", padding, y + 8f, 25f, true)

    val directory = File(context.cacheDir, "bills")
    if (!directory.exists() && !directory.mkdirs()) throw IOException("Could not create the bill image folder.")
    val image = File(directory, "bill-${bill.bill.billNumber}.png")
    FileOutputStream(image).use {
        if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) {
            throw IOException("Could not encode the bill image.")
        }
    }
    val uri: Uri = FileProvider.getUriForFile(
        context, "${context.packageName}.fileprovider", image
    )
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "image/png"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "Bill #${bill.bill.billNumber}")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share bill"))
}
