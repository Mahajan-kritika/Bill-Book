package com.sharmastores.billbook.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Embedded
import androidx.room.Relation
import java.math.BigDecimal

@Entity(tableName = "shop_profile")
data class ShopProfile(
    @PrimaryKey val id: Int = 1,
    val shopName: String = "Sharma Stores",
    val ownerName: String = "",
    val mobile: String = "",
    val address: String = "",
    val upiId: String = "",
    val gstin: String = "",
    val defaultTaxPercent: String = "0",
    val currency: String = "INR"
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val unitPricePaise: Long
)

@Entity(tableName = "bills")
data class Bill(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val billNumber: Long,
    val createdAt: Long,
    val subtotalPaise: Long,
    val discountPaise: Long,
    val discountInput: String,
    val discountIsPercent: Boolean,
    val taxPercent: String,
    val taxPaise: Long,
    val grandTotalPaise: Long,
    val paymentStatus: String = "UNPAID",
    val shopName: String,
    val shopAddress: String,
    val shopMobile: String,
    val upiId: String,
    val ownerName: String = "",
    val gstin: String = ""
)

@Entity(
    tableName = "bill_items",
    foreignKeys = [
        androidx.room.ForeignKey(
            entity = Bill::class,
            parentColumns = ["id"],
            childColumns = ["billId"],
            onDelete = androidx.room.ForeignKey.CASCADE
        )
    ],
    indices = [androidx.room.Index("billId")]
)
data class BillItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val billId: Long,
    val productName: String,
    val quantity: String,
    val unitPricePaise: Long,
    val lineTotalPaise: Long
)

data class BillWithItems(
    @Embedded val bill: Bill,
    @Relation(parentColumn = "id", entityColumn = "billId")
    val items: List<BillItem>
)

data class DraftItem(
    val productId: Long?,
    val name: String,
    val quantity: String,
    val unitPricePaise: Long
)

data class BillDraft(
    val items: List<DraftItem>,
    val discountInput: String,
    val discountIsPercent: Boolean,
    val taxPercent: String
)

data class BillTotals(
    val subtotalPaise: Long,
    val discountPaise: Long,
    val taxablePaise: Long,
    val taxPaise: Long,
    val grandTotalPaise: Long
)

fun Long.asRupees(): String =
    BigDecimal.valueOf(this, 2).setScale(2).toPlainString()
