package com.sharmastores.billbook.data

import org.junit.Assert.assertEquals
import org.junit.Test

class BillCalculatorTest {
    @Test
    fun calculatesRiceAndOilExampleExactly() {
        val result = BillCalculator.calculate(
            BillDraft(
                items = listOf(
                    DraftItem(1, "Rice", "2", 6_000),
                    DraftItem(2, "Oil", "1", 16_500)
                ),
                discountInput = "0",
                discountIsPercent = false,
                taxPercent = "0"
            )
        )
        assertEquals(28_500L, result.subtotalPaise)
        assertEquals(0L, result.discountPaise)
        assertEquals(0L, result.taxPaise)
        assertEquals(28_500L, result.grandTotalPaise)
    }

    @Test
    fun calculatesPercentageDiscountBeforeTax() {
        val result = BillCalculator.calculate(
            BillDraft(listOf(DraftItem(null, "Goods", "1", 100_000)), "10", true, "5")
        )
        assertEquals(100_000L, result.subtotalPaise)
        assertEquals(10_000L, result.discountPaise)
        assertEquals(4_500L, result.taxPaise)
        assertEquals(94_500L, result.grandTotalPaise)
    }

    @Test
    fun calculatesFixedDiscountAndEighteenPercentTax() {
        val result = BillCalculator.calculate(
            BillDraft(listOf(DraftItem(null, "Goods", "1", 50_000)), "50", false, "18")
        )
        assertEquals(5_000L, result.discountPaise)
        assertEquals(8_100L, result.taxPaise)
        assertEquals(53_100L, result.grandTotalPaise)
    }

    @Test
    fun rejectsDiscountLargerThanSubtotal() {
        val error = runCatching {
            BillCalculator.calculate(
                BillDraft(listOf(DraftItem(null, "Goods", "1", 1_000)), "20", false, "0")
            )
        }.exceptionOrNull()
        assertEquals("Discount cannot exceed the subtotal.", error?.message)
    }
}
