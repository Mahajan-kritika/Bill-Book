package com.sharmastores.billbook.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ShopProfileDao {
    @Query("SELECT * FROM shop_profile WHERE id = 1")
    fun observe(): Flow<ShopProfile?>

    @Query("SELECT * FROM shop_profile WHERE id = 1")
    suspend fun get(): ShopProfile?

    @Upsert
    suspend fun save(profile: ShopProfile)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(product: Product): Long

    @Query("DELETE FROM products WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface BillDao {
    @Transaction
    @Query("SELECT * FROM bills ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<BillWithItems>>

    @Transaction
    @Query("SELECT * FROM bills WHERE id = :id")
    suspend fun getById(id: Long): BillWithItems?

    @Query("SELECT COALESCE(MAX(billNumber), 0) + 1 FROM bills")
    suspend fun nextBillNumber(): Long

    @Insert
    suspend fun insert(bill: Bill): Long

    @Insert
    suspend fun insertItems(items: List<BillItem>)
}
