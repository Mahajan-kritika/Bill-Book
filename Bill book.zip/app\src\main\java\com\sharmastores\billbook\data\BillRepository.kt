package com.sharmastores.billbook.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

class BillRepository(private val database: AppDatabase) {
    val products: Flow<List<Product>> = database.productDao().observeAll()
    val bills: Flow<List<BillWithItems>> = database.billDao().observeAll()
    val profile: Flow<ShopProfile?> = database.shopProfileDao().observe()

    suspend fun saveProfile(profile: ShopProfile) = database.shopProfileDao().save(profile)
    suspend fun ensureProfile() {
        if (database.shopProfileDao().get() == null) {
            database.shopProfileDao().save(ShopProfile())
        }
    }
    suspend fun saveProduct(product: Product) = database.productDao().save(product)
    suspend fun deleteProduct(id: Long) = database.productDao().delete(id)

    suspend fun saveBill(draft: BillDraft, profile: ShopProfile): BillWithItems {
        val totals = BillCalculator.calculate(draft)
        val now = System.currentTimeMillis()
        val bill = database.withTransaction {
            val billDao = database.billDao()
            val number = billDao.nextBillNumber()
            val billId = billDao.insert(
                Bill(
                    billNumber = number,
                    createdAt = now,
                    subtotalPaise = totals.subtotalPaise,
                    discountPaise = totals.discountPaise,
                    discountInput = draft.discountInput,
                    discountIsPercent = draft.discountIsPercent,
                    taxPercent = draft.taxPercent,
                    taxPaise = totals.taxPaise,
                    grandTotalPaise = totals.grandTotalPaise,
                    shopName = profile.shopName,
                    shopAddress = profile.address,
                    shopMobile = profile.mobile,
                    upiId = profile.upiId,
                    ownerName = profile.ownerName,
                    gstin = profile.gstin
                )
            )
            billDao.insertItems(draft.items.map {
                BillItem(
                    billId = billId,
                    productName = it.name.trim(),
                    quantity = it.quantity.trim(),
                    unitPricePaise = it.unitPricePaise,
                    lineTotalPaise = BillCalculator.lineTotal(it)
                )
            })
            billDao.getById(billId) ?: error("Saved bill could not be loaded")
        }
        return bill
    }
}
