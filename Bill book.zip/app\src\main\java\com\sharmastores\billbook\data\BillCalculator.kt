package com.sharmastores.billbook.data

import java.math.BigDecimal
import java.math.RoundingMode

object BillCalculator {
    fun lineTotal(item: DraftItem): Long {
        val quantity = item.quantity.toBigDecimalOrNull()
            ?: throw IllegalArgumentException("Enter a valid quantity for ${item.name}.")
        require(quantity > BigDecimal.ZERO) { "Quantity must be greater than zero." }
        require(item.unitPricePaise >= 0) { "Price cannot be negative." }
        return quantity.multiply(BigDecimal.valueOf(item.unitPricePaise))
            .setScale(0, RoundingMode.HALF_UP).longValueExact()
    }

    fun calculate(draft: BillDraft): BillTotals {
        require(draft.items.isNotEmpty()) { "Add at least one item to the bill." }
        val subtotal = draft.items.sumOf(::lineTotal)
        val discountValue = draft.discountInput.toBigDecimalOrNull()
            ?: throw IllegalArgumentException("Enter a valid discount.")
        require(discountValue >= BigDecimal.ZERO) { "Discount cannot be negative." }
        val discount = if (draft.discountIsPercent) {
            require(discountValue <= BigDecimal("100")) { "Percentage discount cannot exceed 100%." }
            BigDecimal.valueOf(subtotal).multiply(discountValue)
                .divide(BigDecimal("100"), 0, RoundingMode.HALF_UP).longValueExact()
        } else {
            discountValue.multiply(BigDecimal("100"))
                .setScale(0, RoundingMode.HALF_UP).longValueExact()
        }
        require(discount <= subtotal) { "Discount cannot exceed the subtotal." }
        val taxPercent = draft.taxPercent.toBigDecimalOrNull()
            ?: throw IllegalArgumentException("Enter a valid tax percentage.")
        require(taxPercent >= BigDecimal.ZERO && taxPercent <= BigDecimal("100")) {
            "Tax percentage must be between 0 and 100."
        }
        val taxable = subtotal - discount
        val tax = BigDecimal.valueOf(taxable).multiply(taxPercent)
            .divide(BigDecimal("100"), 0, RoundingMode.HALF_UP).longValueExact()
        return BillTotals(subtotal, discount, taxable, tax, taxable + tax)
    }
}
