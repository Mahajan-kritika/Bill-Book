# Bill Book

Offline-first Android billing app for a small shop, built with Kotlin, Jetpack Compose, Room, and ZXing.

## Features

- Local product catalogue, shop profile, and persistent bill history.
- Decimal-safe bill totals in paise, with fixed/percentage discounts and configurable tax.
- Transactional bill and item saves with sequential bill numbers.
- UPI payment QR generation for the exact saved or previewed amount.
- PNG receipt rendering and Android Sharesheet sharing through a restricted `FileProvider`.
- Dashboard and date-filterable/searchable history with daily sales totals.

## Build

Requirements: Android Studio with its bundled JDK 17, Android SDK Platform 35, and Android SDK Build-Tools 35.0.0.

In Android Studio, install the required SDK components in **Tools > SDK Manager**, open this folder, select the bundled JDK 17 under **Settings > Build Tools > Gradle**, and allow Gradle sync. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. For a terminal build with Gradle installed:

```powershell
gradle :app:assembleDebug
```

The APK is written to `app\build\outputs\apk\debug\app-debug.apk`.

The current development environment did not have Java, Gradle, or Android SDK configured, so neither the Gradle tests nor an APK build could be run here. Install Android Studio with JDK 17, Android SDK Platform 35, and Build-Tools 35.0.0 to build and install it.

## Project layout

- `data`: Room entities/DAOs/database, repository, and bill calculations.
- `ui`: Compose screens, state holder, QR generation, and PNG/share handling.
- `app/src/test`: bill calculation unit tests.

## Validation notes

Unit test source covers the requested rice/oil example, percentage and fixed discounts, tax ordering, and invalid discounts. These tests remain unexecuted until the Android/Gradle toolchain is installed. Real-device airplane-mode behavior, scanning with a UPI app, and WhatsApp rendering/sharing require an Android device and cannot be verified in this environment.
