package com.sharmastores.billbook.ui

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sharmastores.billbook.BillBookApplication
import com.sharmastores.billbook.data.Bill
import com.sharmastores.billbook.data.BillCalculator
import com.sharmastores.billbook.data.BillDraft
import com.sharmastores.billbook.data.BillItem
import com.sharmastores.billbook.data.BillWithItems
import com.sharmastores.billbook.data.DraftItem
import com.sharmastores.billbook.data.Product
import com.sharmastores.billbook.data.ShopProfile
import com.sharmastores.billbook.data.asRupees
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

private val Green = Color(0xFF1E6B4E)
private val SoftGreen = Color(0xFFE7F2EB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = (application as BillBookApplication).repository
        setContent {
            val vm: BillViewModel = viewModel(factory = BillViewModel.Factory(repository))
            BillBookTheme { BillBookApp(vm) }
        }
    }
}

@Composable
private fun BillBookTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MaterialTheme.colorScheme.copy(
            primary = Green,
            secondary = Color(0xFF5B806C),
            surface = Color.White,
            background = Color(0xFFF6F8F6)
        ),
        content = content
    )
}

private enum class Page(val label: String) {
    HOME("Home"), NEW_BILL("New Bill"), HISTORY("History"), PRODUCTS("Products"), SETTINGS("Settings")
}

@Composable
private fun BillBookApp(vm: BillViewModel) {
    val products by vm.products.collectAsStateWithLifecycle()
    val bills by vm.bills.collectAsStateWithLifecycle()
    val profile by vm.profile.collectAsStateWithLifecycle()
    val message by vm.message.collectAsState()
    var page by remember { mutableStateOf(Page.HOME) }
    var openedBill by remember { mutableStateOf<BillWithItems?>(null) }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar {
                Page.values().forEach { destination ->
                    val icon = when (destination) {
                        Page.HOME -> Icons.Default.Home
                        Page.NEW_BILL -> Icons.Default.Add
                        Page.HISTORY -> Icons.Default.ReceiptLong
                        Page.PRODUCTS -> Icons.Default.Inventory2
                        Page.SETTINGS -> Icons.Default.Settings
                    }
                    NavigationBarItem(
                        selected = page == destination,
                        onClick = { page = destination },
                        icon = { Icon(icon, contentDescription = destination.label) },
                        label = { Text(destination.label) }
                    )
                }
            }
        }
    ) { insets ->
        Column(Modifier.fillMaxSize().padding(insets)) {
            when (page) {
                Page.HOME -> HomeScreen(
                    profile, bills,
                    onNewBill = { page = Page.NEW_BILL },
                    onOpenBill = { openedBill = it },
                    onReports = { page = Page.HISTORY; openedBill = null }
                )
                Page.NEW_BILL -> NewBillScreen(
                    products, profile,
                    onSave = { draft, onSaved ->
                        vm.saveBill(draft) {
                            onSaved()
                            openedBill = it
                        }
                    }
                )
                Page.HISTORY -> HistoryScreen(bills, onOpenBill = { openedBill = it })
                Page.PRODUCTS -> ProductsScreen(products, vm::saveProduct, vm::deleteProduct)
                Page.SETTINGS -> SettingsScreen(profile, vm::saveProfile)
            }
        }
    }
    openedBill?.let { bill ->
        BillDetailsDialog(bill, onDismiss = { openedBill = null })
    }
}

@Composable
private fun HomeScreen(
    profile: ShopProfile,
    bills: List<BillWithItems>,
    onNewBill: () -> Unit,
    onOpenBill: (BillWithItems) -> Unit,
    onReports: () -> Unit
) {
    val today = todayBills(bills)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text(profile.shopName, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Your local billing dashboard", color = Color.Gray)
        Spacer(Modifier.height(18.dp))
        ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = SoftGreen)) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Text("Today's sales", color = Green)
                Text("₹${today.sumOf { it.bill.grandTotalPaise }.asRupees()}", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text("${today.size} bills generated today")
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = onNewBill, modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("New Bill")
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onReports, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Assessment, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Sales report and bill history")
        }
        Spacer(Modifier.height(22.dp))
        Text("Recent bills", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        if (bills.isEmpty()) EmptyState("No bills yet. Create your first bill.")
        bills.take(8).forEach { BillRow(it, onClick = { onOpenBill(it) }) }
    }
}

@Composable
private fun HistoryScreen(bills: List<BillWithItems>, onOpenBill: (BillWithItems) -> Unit) {
    var search by remember { mutableStateOf("") }
    var dateFilter by remember { mutableStateOf("") }
    val filtered = bills.filter { entry ->
        (search.isBlank() || entry.bill.billNumber.toString().contains(search.trim())) &&
            (dateFilter.isBlank() || dateString(entry.bill.createdAt).contains(dateFilter.trim(), ignoreCase = true))
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Text("Bill history & sales", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 14.dp))
        val today = todayBills(bills)
        val total = today.sumOf { it.bill.grandTotalPaise }
        val average = if (today.isEmpty()) 0L else total / today.size
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SummaryCard("Today's sales", "₹${total.asRupees()}", Modifier.weight(1f))
            SummaryCard("Bills today", today.size.toString(), Modifier.weight(1f))
            SummaryCard("Average", "₹${average.asRupees()}", Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(search, { search = it }, label = { Text("Search bill number") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(dateFilter, { dateFilter = it }, label = { Text("Filter date (yyyy-MM-dd)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp))
        if (filtered.isEmpty()) EmptyState("No matching bills.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("Sales by date", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            val dailySales = bills.groupBy { dateString(it.bill.createdAt) }
                .toSortedMap(compareByDescending { it })
            items(dailySales.toList(), key = { "daily-${it.first}" }) { (date, entries) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("$date (${entries.size} bills)")
                    Text("₹${entries.sumOf { it.bill.grandTotalPaise }.asRupees()}", fontWeight = FontWeight.SemiBold)
                }
            }
            item {
                Text("All bills", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
            }
            items(filtered, key = { it.bill.id }) { BillRow(it) { onOpenBill(it) } }
        }
    }
}

@Composable
private fun ProductsScreen(
    products: List<Product>,
    onSave: (Product) -> Unit,
    onDelete: (Long) -> Unit
) {
    var editingId by remember { mutableStateOf(0L) }
    var name by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Products", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(search, { search = it }, label = { Text("Search products") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(name, { name = it }, label = { Text("Product name") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(price, { price = it }, label = { Text("Price ₹") }, modifier = Modifier.width(125.dp), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        }
        Button(
            onClick = {
                val paise = priceToPaise(price)
                if (name.isNotBlank() && paise != null) {
                    onSave(Product(id = editingId, name = name.trim(), unitPricePaise = paise))
                    editingId = 0
                    name = ""
                    price = ""
                }
            },
            enabled = name.isNotBlank() && priceToPaise(price) != null,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (editingId == 0L) "Add product" else "Save changes") }
        Spacer(Modifier.height(8.dp))
        if (products.none { it.name.contains(search, ignoreCase = true) }) EmptyState("No products found.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(products.filter { it.name.contains(search, ignoreCase = true) }, key = { it.id }) { product ->
                Card {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(product.name, fontWeight = FontWeight.SemiBold)
                            Text("₹${product.unitPricePaise.asRupees()}", color = Green)
                        }
                        TextButton(onClick = {
                            editingId = product.id
                            name = product.name
                            price = product.unitPricePaise.asRupees()
                        }) { Text("Edit") }
                        TextButton(onClick = { onDelete(product.id) }) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(profile: ShopProfile, onSave: (ShopProfile) -> Unit) {
    var shopName by remember(profile) { mutableStateOf(profile.shopName) }
    var owner by remember(profile) { mutableStateOf(profile.ownerName) }
    var mobile by remember(profile) { mutableStateOf(profile.mobile) }
    var address by remember(profile) { mutableStateOf(profile.address) }
    var upi by remember(profile) { mutableStateOf(profile.upiId) }
    var gstin by remember(profile) { mutableStateOf(profile.gstin) }
    var tax by remember(profile) { mutableStateOf(profile.defaultTaxPercent) }
    val taxValue = tax.toBigDecimalOrNull()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("Shop settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        FormField("Shop name", shopName) { shopName = it }
        FormField("Owner name", owner) { owner = it }
        FormField("Mobile number", mobile, KeyboardType.Phone) { mobile = it }
        FormField("Shop address", address) { address = it }
        FormField("UPI ID", upi) { upi = it }
        FormField("GSTIN (optional)", gstin) { gstin = it }
        FormField("Default tax percentage", tax, KeyboardType.Decimal) { tax = it }
        Text("Currency: Indian Rupee (INR)", color = Color.Gray, modifier = Modifier.padding(vertical = 6.dp))
        Button(
            onClick = {
                if (shopName.isNotBlank() && taxValue != null && taxValue >= BigDecimal.ZERO && taxValue <= BigDecimal("100")) {
                    onSave(profile.copy(
                        shopName = shopName.trim(), ownerName = owner.trim(), mobile = mobile.trim(),
                        address = address.trim(), upiId = upi.trim(), gstin = gstin.trim(),
                        defaultTaxPercent = taxValue.stripTrailingZeros().toPlainString()
                    ))
                }
            },
            enabled = shopName.isNotBlank() && taxValue != null &&
                taxValue >= BigDecimal.ZERO && taxValue <= BigDecimal("100"),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save shop profile") }
        Text("Bills keep a snapshot of the shop details used when they were created.", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun NewBillScreen(
    products: List<Product>,
    profile: ShopProfile,
    onSave: (BillDraft, () -> Unit) -> Unit
) {
    val draftItems = remember { mutableStateListOf<DraftItem>() }
    var productSearch by remember { mutableStateOf("") }
    var customName by remember { mutableStateOf("") }
    var customPrice by remember { mutableStateOf("") }
    var discount by remember { mutableStateOf("0") }
    var percentDiscount by remember { mutableStateOf(false) }
    var taxPercent by remember(profile.defaultTaxPercent) { mutableStateOf(profile.defaultTaxPercent) }
    var preview by remember { mutableStateOf<BillWithItems?>(null) }
    val draft = BillDraft(draftItems.toList(), discount, percentDiscount, taxPercent)
    val calculation = remember(draftItems.toList(), discount, percentDiscount, taxPercent) {
        runCatching { BillCalculator.calculate(draft) }
    }
    val totals = calculation.getOrNull()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("New bill", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(profile.shopName, color = Green)
        Spacer(Modifier.height(12.dp))
        Text("Add from catalogue", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            productSearch,
            { productSearch = it },
            label = { Text("Search products") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        val matchingProducts = products.filter { it.name.contains(productSearch, ignoreCase = true) }
        if (matchingProducts.isEmpty()) Text("No matching products. Add a custom item or save it in Products.", color = Color.Gray)
        matchingProducts.forEach { product ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(product.name)
                    Text("₹${product.unitPricePaise.asRupees()}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = {
                    val index = draftItems.indexOfFirst { it.productId == product.id }
                    if (index >= 0) {
                        val existing = draftItems[index]
                        val quantity = existing.quantity.toBigDecimalOrNull() ?: BigDecimal.ONE
                        draftItems[index] = existing.copy(quantity = quantity.add(BigDecimal.ONE).stripTrailingZeros().toPlainString())
                    } else draftItems.add(DraftItem(product.id, product.name, "1", product.unitPricePaise))
                }) { Text("+ Add") }
            }
        }
        Divider(Modifier.padding(vertical = 8.dp))
        Text("Custom item", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(customName, { customName = it }, label = { Text("Name") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(customPrice, { customPrice = it }, label = { Text("Price ₹") }, modifier = Modifier.width(120.dp), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        }
        TextButton(
            onClick = {
                val value = priceToPaise(customPrice)
                if (customName.isNotBlank() && value != null) {
                    draftItems.add(DraftItem(null, customName.trim(), "1", value))
                    customName = ""
                    customPrice = ""
                }
            },
            enabled = customName.isNotBlank() && priceToPaise(customPrice) != null
        ) { Text("Add custom item") }
        Spacer(Modifier.height(6.dp))
        draftItems.forEachIndexed { index, item ->
            Card(Modifier.padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.name, fontWeight = FontWeight.Medium)
                        Text("₹${item.unitPricePaise.asRupees()} each", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedTextField(
                        value = item.quantity,
                        onValueChange = { value -> draftItems[index] = item.copy(quantity = value) },
                        label = { Text("Qty") },
                        modifier = Modifier.width(90.dp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                    TextButton(onClick = { draftItems.removeAt(index) }) { Text("Remove") }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(discount, { discount = it }, label = { Text(if (percentDiscount) "Discount %" else "Discount ₹") }, modifier = Modifier.weight(1f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            TextButton(onClick = { percentDiscount = !percentDiscount }) { Text(if (percentDiscount) "%" else "₹") }
            OutlinedTextField(taxPercent, { taxPercent = it }, label = { Text("Tax %") }, modifier = Modifier.width(110.dp), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        }
        totals?.let { totals ->
            ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = SoftGreen), modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                Column(Modifier.padding(16.dp)) {
                    TotalLine("Subtotal", totals.subtotalPaise)
                    TotalLine("Discount", -totals.discountPaise)
                    TotalLine("Tax", totals.taxPaise)
                    Divider(Modifier.padding(vertical = 6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Grand total", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        Text("₹${totals.grandTotalPaise.asRupees()}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = Green)
                    }
                }
            }
        } ?: Text(
            calculation.exceptionOrNull()?.message ?: "Add bill items and enter valid amounts to calculate the total.",
            color = Color.Gray
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = { totals?.let { preview = makePreview(draft, profile, it) } },
                enabled = totals != null,
                modifier = Modifier.weight(1f)
            ) { Text("Preview bill") }
            Button(
                onClick = {
                    if (totals != null) {
                        onSave(draft) {
                            draftItems.clear()
                            discount = "0"
                            percentDiscount = false
                            taxPercent = profile.defaultTaxPercent
                        }
                    }
                },
                enabled = totals != null,
                modifier = Modifier.weight(1f)
            ) { Text("Save bill") }
        }
        Spacer(Modifier.height(20.dp))
    }
    preview?.let { BillDetailsDialog(it, onDismiss = { preview = null }, canShare = false) }
}

@Composable
private fun BillDetailsDialog(
    bill: BillWithItems,
    onDismiss: () -> Unit,
    canShare: Boolean = true
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (bill.bill.id == 0L) "Bill preview" else "Bill #${bill.bill.billNumber}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(bill.bill.shopName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (bill.bill.ownerName.isNotBlank()) Text("Owner: ${bill.bill.ownerName}")
                if (bill.bill.shopAddress.isNotBlank()) Text(bill.bill.shopAddress)
                if (bill.bill.shopMobile.isNotBlank()) Text(bill.bill.shopMobile)
                if (bill.bill.gstin.isNotBlank()) Text("GSTIN: ${bill.bill.gstin}")
                Text(dateTime(bill.bill.createdAt), color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                bill.items.forEach { item ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${item.productName}  x${item.quantity}")
                        Text("₹${item.lineTotalPaise.asRupees()}")
                    }
                }
                Divider(Modifier.padding(vertical = 8.dp))
                TotalLine("Subtotal", bill.bill.subtotalPaise)
                TotalLine("Discount", -bill.bill.discountPaise)
                TotalLine("Tax", bill.bill.taxPaise)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Grand total", fontWeight = FontWeight.Bold)
                    Text("₹${bill.bill.grandTotalPaise.asRupees()}", fontWeight = FontWeight.Bold, color = Green)
                }
                Spacer(Modifier.height(12.dp))
                val uri = upiUri(bill)
                if (uri != null) {
                    Image(createQrBitmap(uri, 300).asImageBitmap(), contentDescription = "UPI payment QR", modifier = Modifier.size(190.dp).align(Alignment.CenterHorizontally))
                    Text("Scan to pay exactly ₹${bill.bill.grandTotalPaise.asRupees()}", modifier = Modifier.align(Alignment.CenterHorizontally))
                } else {
                    Text("UPI QR unavailable. Configure a valid UPI ID in Settings.", color = Color.Gray)
                }
                Text("Thank you for shopping with us!", modifier = Modifier.padding(top = 10.dp))
            }
        },
        confirmButton = {
            Row {
                if (canShare) TextButton(onClick = {
                    try {
                        shareBillImage(context, bill)
                    } catch (error: Exception) {
                        Toast.makeText(
                            context,
                            error.message ?: "Could not create or share the bill image.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }) { Text("Share image") }
                TextButton(onClick = onDismiss) { Text("Close") }
            }
        }
    )
}

private fun makePreview(draft: BillDraft, profile: ShopProfile, totals: com.sharmastores.billbook.data.BillTotals): BillWithItems {
    val items = draft.items.map {
        BillItem(
            billId = 0,
            productName = it.name,
            quantity = it.quantity,
            unitPricePaise = it.unitPricePaise,
            lineTotalPaise = BillCalculator.lineTotal(it)
        )
    }
    return BillWithItems(
        bill = Bill(
            id = 0, billNumber = 0, createdAt = System.currentTimeMillis(),
            subtotalPaise = totals.subtotalPaise, discountPaise = totals.discountPaise,
            discountInput = draft.discountInput, discountIsPercent = draft.discountIsPercent,
            taxPercent = draft.taxPercent, taxPaise = totals.taxPaise,
            grandTotalPaise = totals.grandTotalPaise, shopName = profile.shopName,
            shopAddress = profile.address, shopMobile = profile.mobile, upiId = profile.upiId,
            ownerName = profile.ownerName, gstin = profile.gstin
        ),
        items = items
    )
}

@Composable
private fun BillRow(bill: BillWithItems, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Bill #${bill.bill.billNumber}", fontWeight = FontWeight.SemiBold)
                Text(dateTime(bill.bill.createdAt), color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
            Text("₹${bill.bill.grandTotalPaise.asRupees()}", color = Green, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(10.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
private fun TotalLine(title: String, paise: Long) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title)
        Text("₹${paise.asRupees()}")
    }
}

@Composable
private fun FormField(label: String, value: String, keyboardType: KeyboardType = KeyboardType.Text, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType)
    )
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.Gray)
    }
}

private fun priceToPaise(value: String): Long? {
    val amount = value.trim().toBigDecimalOrNull() ?: return null
    if (amount < BigDecimal.ZERO) return null
    return runCatching {
        amount.multiply(BigDecimal("100")).setScale(0, RoundingMode.HALF_UP).longValueExact()
    }.getOrNull()
}

private fun todayBills(bills: List<BillWithItems>): List<BillWithItems> {
    val calendar = Calendar.getInstance()
    calendar.set(Calendar.HOUR_OF_DAY, 0)
    calendar.set(Calendar.MINUTE, 0)
    calendar.set(Calendar.SECOND, 0)
    calendar.set(Calendar.MILLISECOND, 0)
    val start = calendar.timeInMillis
    calendar.add(Calendar.DAY_OF_YEAR, 1)
    val end = calendar.timeInMillis
    return bills.filter { it.bill.createdAt >= start && it.bill.createdAt < end }
}

private fun dateString(timestamp: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(timestamp))
private fun dateTime(timestamp: Long) = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(timestamp))
